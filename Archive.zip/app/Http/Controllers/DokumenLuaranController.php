<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDokumenLuaranRequest;
use App\Http\Requests\UpdateDokumenLuaranRequest;
use App\Models\DokumenLuaran;

class DokumenLuaranController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDokumenLuaranRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DokumenLuaran $dokumenLuaran)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DokumenLuaran $dokumenLuaran)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDokumenLuaranRequest $request, DokumenLuaran $dokumenLuaran)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DokumenLuaran $dokumenLuaran)
    {
        //
    }
}
